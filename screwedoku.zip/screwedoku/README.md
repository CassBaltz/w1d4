# Screwedoku

Students: Ask a TA to send out the zipfile.

TAs: If you're zipping up this project, run the pull_and_create.sh script to zip it.  Don't just run the `zip` command.


## For TAs: Making changes

If you want to update the README or affect all the levels, commit your changes on master and then run the `update.sh` script.  For example `update.sh Gemfile`.

Then run the pull_all_branches_and_zip.sh to make a new zipfile out of the project for students.


## Copyright

© Asher King Abramson and App Academy.  All rights reserved.  Do not share without written consent of the authors.


[zip file]: ./screwedoku.zip
